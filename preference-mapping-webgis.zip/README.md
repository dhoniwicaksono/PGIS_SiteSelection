Preference Mapping WebGIS Prototype
==================================

How to publish:
1. Create a GitHub repository (public).
2. Upload the files in this ZIP to the repository root.
3. In repository Settings -> Pages, set Source to "main branch / (root)".
4. Access your site at: https://<your-username>.github.io/<repo-name>/

This bundle contains:
- index.html  (the WebGIS app using Leaflet CDN)
